import sys
import os
import httplib
import json
import urllib
import ast

print('Loading Function')
postreqdata = json.loads(open(os.environ['req']).read())

ARMResource = 'https://management.core.windows.net/'

ClientSecret = postreqdata['ClientSecret']

ResourceGroupName = postreqdata['ResourceGroupName']

ClientID = postreqdata['ClientID']

TenantID = postreqdata['TenantID']

Attacker = postreqdata['Attacker']

NetworkSecurityGroupName = postreqdata['NetworkSecurityGroupName']

SubscriptionID = postreqdata['SubscriptionID']

Region = postreqdata['Region']

Host = 'login.windows.net'

URL = '/' + TenantID + '/oauth2/token/'

Headers = { 'User-Agent': 'python', 'Content-Type': 'application/x-www-form-urlencoded', }

tempstr = { 'resource' : ARMResource, 'client_id' : ClientID, 'grant_type' : 'client_credentials', 'client_secret' : ClientSecret }

QueryStr = urllib.urlencode(tempstr)

conn = httplib.HTTPSConnection(Host)

conn.request("POST", URL, QueryStr, Headers)

response = conn.getresponse()

data = response.read()

datadict = ast.literal_eval(data)

AccessToken = datadict['access_token']

Host = 'management.azure.com'

URL = '/subscriptions/' + SubscriptionID + '/resourceGroups/' + ResourceGroupName + '/providers/Microsoft.Network/networkSecurityGroups/' + NetworkSecurityGroupName + '/securityRules/quarantine?api-version=2017-08-01'

Headers = { 'Content-Type': 'application/json', 'Authorization': 'bearer ' + AccessToken }

Body = json.dumps({
  "properties": {
    "protocol": "*",
    "sourceAddressPrefix": Attacker,
    "destinationAddressPrefix": "*",
    "access": "Deny",
    "destinationPortRange": "*",
    "sourcePortRange": "*",
    "priority": 100,
    "direction": "Outbound"
  }
})

conn = httplib.HTTPSConnection(Host)

conn.request("PUT", URL, Body, Headers)

response = conn.getresponse()

data = response.read()

print Host
print ARMResource
print ClientSecret
print ResourceGroupName
print ClientID
print TenantID
print Attacker
print NetworkSecurityGroupName
print SubscriptionID
print QueryStr
print 'Response: ', response.status, response.reason
print 'Data:'
print data